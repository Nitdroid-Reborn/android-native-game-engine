#include "ScriptSourceFactory.h"

ScriptSource* ScriptSourceFactory::Create(){return new ScriptSource;}
