<?php
	$CALLED_FROM_INDEX = true;
		
	if (!isset($_GET))
	{
		header("HTTP/1.0 400 Bad Request");
		die("Unexpected type of request: {$_GET["request"]}");
	}
	
	// pewnie niezbyt to �adne
	//if (is_callable(pg_connect))
		$sDBFile = "pgsql.php";
	//else
	//	$sDBFile = "mysql.php";
		
	switch ($_GET["request"])
	{
		case "set":
			require("AddScore.php");
			break;
		case "get":
			require("ReturnScores.php");
			break;
		case "list":
			require("ScoreTable.php");
			break;
		default:
			header("HTTP/1.0 400 Bad Request");
			die("Unexpected type of request: {$_GET["request"]}");
	}
?>
