<?php
	if (!isset($CALLED_FROM_INDEX))
	{
		header("HTTP/1.0 403 Forbidden");
		die("Forbidden");
	}
	
	require($sDBFile);
	$sql = new SQL();
	$sql->Connect();
	
	$result = $sql->Q("SELECT Name, Score FROM ski_scores ORDER BY Score DESC LIMIT 10");
	if ($sql->Num($result) === 0)
	{
		die("Brak wynik�w");
	}
	else
	{
		header("Content-Type: image/png");
		
		$img = imagecreatefrompng("./data/content_bg.png");
		$textClr = imagecolorallocate($img, 0, 0, 0);
		$fontPth = "./data/Sylfaen.ttf";

		$i = 1;
		while ($aEntry = pg_fetch_assoc($result))
		{
			imagefttext($img, 12, 0,  10, 90 + $i * 20, $textClr, $fontPth, "$i.");
			imagefttext($img, 12, 0,  30, 90 + $i * 20, $textClr, $fontPth, $aEntry["name"]);
			imagefttext($img, 12, 0, 300, 90 + $i * 20, $textClr, $fontPth, $aEntry["score"]);
			++$i;
		}

		imagepng($img);
		imagedestroy($img);
	}
?>
