<?php
	if (!isset($CALLED_FROM_INDEX))
	{
		header("HTTP/1.0 403 Forbidden");
		die("Forbidden");
	}
	
	class SQL
	{
		private $mConn = null;
		private $mConnected = false;
		
		public function Connect()
		{
			$this->mConn = mysql_connect("localhost", "root", "");
			if (!mysql_select_db("miagk"))
			{
				header("HTTP/1.0 500 Internal Server Error");
				die("Unable to connect to db");
			}
			$this->mConnected = true;
		}
		
		public function Close()
		{
			$this->mConnected = false;
			mysql_close($this->mConn);
		}
		
		public function Q($sQuery)
		{
			if ($this->mConnected)
			{
				$res = mysql_query($sQuery);
				if ($res == null)
				{
					die("dbg: error in query\n\"" . addslashes($sQuery) . "\"\n" . mysql_error());
				}
				return $res;
			}
			else
			{
				throw new Exception("Query error");
			}
			return null;
		}
		
		public function Num($res)
		{
			return mysql_num_rows($res);
		}
		
		public function Res($res)
		{
			return mysql_result($res, 0);
		}
		
		public function Escape($sStr)
		{
			return mysql_real_escape_string($sStr);
		}
	}
	
	
?>