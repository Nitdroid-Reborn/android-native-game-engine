<?php
	if (!isset($CALLED_FROM_INDEX))
	{
		header("HTTP/1.0 403 Forbidden");
		die("Forbidden");
	}
	
	class SQL
	{
		private $mConn = null;
		private $mConnected = false;
		
		public function Connect()
		{
			$this->mConn = pg_connect("host= port= dbname= user= password=");
			if ($this->mConn === false)
			{
				header("HTTP/1.0 500 Internal Server Error");
				die("Unable to connect to db");
			}
			$this->mConnected = true;
		}
		
		public function Close()
		{
			$this->mConnected = false;
			pg_close($this->mConn);
		}
		
		public function Q($sQuery)
		{
			if ($this->mConnected)
			{
				$res = pg_query($sQuery);
				if ($res == null)
				{
					die("dbg: error in query\n\"" . addslashes($sQuery) . "\"\n" . pg_last_error());
				}
				return $res;
			}
			else
			{
				throw new Exception("Query error");
			}
			return null;
		}
		
		public function Num($res)
		{
			return pg_num_rows($res);
		}
		
		public function Res($res)
		{
			return pg_fetch_result($res, 0);
		}
		
		public function Escape($sStr)
		{
			return pg_escape_string($sStr);
		}
	}
	
	
?>
