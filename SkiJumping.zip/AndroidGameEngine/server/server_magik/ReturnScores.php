<?php
	if (!isset($CALLED_FROM_INDEX))
	{
		header("HTTP/1.0 403 Forbidden");
		die("Forbidden");
	}
	
	require($sDBFile);
	$sql = new SQL();
	$sql->Connect();
	
	$result = $sql->Q("SELECT Name, Score FROM ski_scores ORDER BY Score DESC");
	if ($sql->Num($result) === 0)
	{
		die("Brak wyników");
	}
	else
	{
		header('Content-Type: text/html; charset="utf-8"');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Wyniki</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
	<table>
		<tr>
			<th>Imię</th>
			<th>Punkty</th>
		</tr>
<?php
		while ($aEntry = pg_fetch_assoc($result))
		{
			echo "<tr>\n" .
					"<td>{$aEntry["name"]}</td>\n" .
					"<td>{$aEntry["score"]}</td>\n" .
				"</tr>\n";
		}
	}
?>
	</table>
</body>
</html>
