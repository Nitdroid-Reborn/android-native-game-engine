<?php
	if (!isset($CALLED_FROM_INDEX))
	{
		header("HTTP/1.0 403 Forbidden");
		die("Forbidden");
	}
	
	$sSaltedHash = "-##%s_rawr!";
	
	$sLogin = $_GET["name"];
	$iPoints = intval($_GET["pts"]);
	$sToken = $_SERVER["HTTP_X_SECURITY"];
	
	if (strlen($sLogin) === 0 || 
		$iPoints <= 0 || 
		!isset($sToken) || 
		$sToken !== md5(sprintf($sSaltedHash, $sLogin . $iPoints)))
	{
		header("HTTP/1.0 400 Bad Request");
		die("Data parsing error");
	}
	
	require($sDBFile);
	$sql = new SQL();
	$sql->Connect();
	
	$sLogin = $sql->Escape($sLogin);
	$result = $sql->Q("SELECT Id FROM ski_scores WHERE Name = '{$sLogin}'");
	if ($sql->Num($result) === 0)
	{
		$sql->Q("INSERT INTO ski_scores (Name, Score) VALUES ('{$sLogin}', {$iPoints})");
	}
	else
	{
		$iId = $sql->Res($result);
		$sql->Q("UPDATE ski_scores SET Score = {$iPoints} WHERE Id = {$iId} AND Score < {$iPoints}");
	}
	
	echo "ok";
?>
